# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

df = spark.read.parquet(f"{presentation_folder_path}/races_results")

# COMMAND ----------

df.show(5)

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum

# COMMAND ----------

df.select(count("*")).show()

# COMMAND ----------

df.select(countDistinct("races_name")).show()

# COMMAND ----------

df.select(sum("results_points")).show()

# COMMAND ----------

df.filter(df.drivers_name == 'Lewis Hamilton').select(sum("results_points").alias("ttl_points"), countDistinct("races_name").alias("dist_races")).show()

# COMMAND ----------

df_grouped = df.groupBy("races_year","drivers_name").agg(sum("results_points").alias("ttl_points"), countDistinct("races_name").alias("dist_races"))

# COMMAND ----------

df_grouped.show(5)

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import desc, rank

# COMMAND ----------

driverrank = Window.partitionBy("races_year").orderBy(desc("ttl_points"))

df_ranked = df_grouped.withColumn("rank", rank().over(driverrank))

# COMMAND ----------

df_ranked.show(10)

# COMMAND ----------

from pyspark.sql.functions import when, col

# COMMAND ----------

df_grouped = df.groupBy("races_year","const_name").agg(sum("results_points").alias("ttl_points"), sum(when(df.results_points == 1, 1).otherwise(0)).alias("wins"))

# COMMAND ----------

df_grouped.show(5)

# COMMAND ----------

team_stats = Window.partitionBy("races_year").orderBy(desc("ttl_points"), desc("wins"))
df_grouped_final = df_grouped.withColumn("rank", rank().over(team_stats))

# COMMAND ----------

df_grouped_final.filter(df_grouped_final.races_year == 2017).show()

# COMMAND ----------


# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races")
circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits")

# COMMAND ----------

joined_df = circuits_df.join(races_df, on= 'circuitId', how='inner')

# COMMAND ----------

### we can also do below

joined_df = circuits_df.join(races_df, circuits_df.circuitId == races_df.circuitId, how='inner')

# COMMAND ----------

joined_df.show(5)

# COMMAND ----------

races_df = races_df.where((races_df.year == 2021) & (races_df.round <=5))
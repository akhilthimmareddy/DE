# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

race_results_df.createTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from v_race_results

# COMMAND ----------

df = spark.sql("select * from v_race_results")

# COMMAND ----------

df

# COMMAND ----------

# MAGIC %md
# MAGIC #### global temp view

# COMMAND ----------


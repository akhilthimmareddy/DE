# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races")
results_df = spark.read.parquet(f"{processed_folder_path}/results")
const_df = spark.read.parquet(f"{processed_folder_path}/constructors")
circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits")
drivers_df = spark.read.parquet(f"{processed_folder_path}/drivers")

# COMMAND ----------

from pyspark.sql.functions import col,current_timestamp

# COMMAND ----------

races_df = races_df.select([col(c).alias(f"races_{c}") for c in races_df.columns])
results_df = results_df.select([col(c).alias(f"results_{c}") for c in results_df.columns])
const_df = const_df.select([col(c).alias(f"const_{c}") for c in const_df.columns])
circuits_df = circuits_df.select([col(c).alias(f"circuits_{c}") for c in circuits_df.columns])
drivers_df = drivers_df.select([col(c).alias(f"drivers_{c}") for c in drivers_df.columns])

# COMMAND ----------

races_df.columns
# results_df.columns
# const_df.columns
# circuits_df.columns
# drivers_df.columns

# COMMAND ----------

races_circuits_df = races_df.join(circuits_df, races_df.races_circuitId == circuits_df.circuits_circuitId, "inner")

# COMMAND ----------

races_results_df = results_df.join(races_circuits_df, results_df.results_raceId == races_circuits_df.races_raceId, "inner") \
                             .join(drivers_df,results_df.results_driverId == drivers_df.drivers_driverId, "inner")\
                             .join(const_df, results_df.results_constructorId == const_df.const_constructorId, "inner")

# COMMAND ----------

races_results_df = races_results_df.withColumn("ingestion_date", current_timestamp())

# COMMAND ----------

races_results_df.columns

# COMMAND ----------

races_results_df = races_results_df.select("races_year","races_name", "races_date", "circuits_location", "drivers_name", "drivers_number", "drivers_nationality", "const_name", "results_grid", "results_fastestLap", "races_race_date_time", "results_points", "ingestion_date")

# COMMAND ----------

races_results_df.show(5)

# COMMAND ----------

display(races_results_df.where("races_year == 2020 and races_name == 'Abu Dhabi Grand Prix' ").orderBy(races_results_df.results_points.desc()))

# COMMAND ----------

races_results_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/races_results")

# COMMAND ----------

df = spark.read.parquet(f"{presentation_folder_path}/races_results")

# COMMAND ----------

driver_standings = races_results_df.groupBy().agg(sum(int"results_points").alias("ttl_points"))

# COMMAND ----------

from pyspark.sql.functions import when, col

# COMMAND ----------

df_grouped = df.groupBy("races_year","drivers_name").agg(sum(col("results_points").cast("int")).alias("ttl_points"), countDistinct("races_name").alias("dist_races"))
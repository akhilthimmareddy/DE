# Databricks notebook source
races_df = spark.read \
.option("header", True) \
.option("inferSchema", True) \
.csv("dbfs:/mnt/formula1dl/raw/races.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### select df

# COMMAND ----------


races_df = races_df.select('raceId','year', 'round', 'circuitId', 'name', 'date', 'time')


# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename columns

# COMMAND ----------

# MAGIC %md
# MAGIC ### adding new column

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp, lit, concat, to_timestamp
 races_final_df = races_df.withColumn("ingestion_date", current_timestamp())

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, concat, to_timestamp, col, concat_ws

# COMMAND ----------

races_final_df = races_final_df.withColumn("race_date_time", to_timestamp(concat_ws(" ", races_final_df.date, races_final_df.time), "yyyy-MM-dd HH:mm:ss"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

races_final_df.write.mode("overwrite").partitionBy("year").parquet("/mnt/formula1dl/processed/races")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/races")

# COMMAND ----------


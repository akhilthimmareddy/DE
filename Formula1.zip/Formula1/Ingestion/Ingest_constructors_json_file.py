# Databricks notebook source
const_df = spark.read \
.option("inferSchema", True) \
.json("dbfs:/mnt/formula1dl/raw/constructors.json")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### drop cols
# MAGIC

# COMMAND ----------


const_df.drop('url')


# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename columns

# COMMAND ----------

# MAGIC %md
# MAGIC ### adding new column

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

const_df.write.mode("overwrite").parquet("/mnt/formula1dl/processed/constructors")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/constructors")
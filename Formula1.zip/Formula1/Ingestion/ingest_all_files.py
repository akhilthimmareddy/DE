# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------

dbutils.notebook.run("Ingest_circuits_file", 0, {"param_data_source":"PROD"})
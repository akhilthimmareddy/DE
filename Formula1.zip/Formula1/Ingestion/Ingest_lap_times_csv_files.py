# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

laps_schema = StructType(fields=
                        [StructField("raceId", IntegerType(), False),
                         StructField("driverId", IntegerType(), True),
                         StructField("stop", StringType(), True),
                         StructField("lap", IntegerType(), True),
                         StructField("time", StringType()), 
                         StructField("milliseconds", IntegerType(), True)]
                           )

# COMMAND ----------

lap_times_df = spark.read \
.option("header", True) \
.schema(laps_schema) \
.csv("dbfs:/mnt/formula1dl/raw/lap_times/")

# COMMAND ----------

# lap_times_df.show(5)

# COMMAND ----------

from pyspark.sql.functions import col,concat, current_timestamp, lit

# COMMAND ----------

lap_times_df = lap_times_df.withColumn("Ingestion_date", current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

lap_times_df.write.mode("overwrite").parquet("/mnt/formula1dl/processed/lap_times")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/lap_times")

# COMMAND ----------

# df.show(5)
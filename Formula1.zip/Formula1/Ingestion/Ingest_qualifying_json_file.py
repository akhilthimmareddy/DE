# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

qualify_stops_df = spark.read \
.option("header", True) \
.option("inferSchema", True) \
.option("multiLine", True) \
.json("dbfs:/mnt/formula1dl/raw/qualifying/")

# COMMAND ----------

# qualify_stops_df.show(5)

# COMMAND ----------

from pyspark.sql.functions import col,concat, current_timestamp, lit

# COMMAND ----------

qualify_stops_df = qualify_stops_df.withColumn("Ingestion_date", current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

qualify_stops_df.write.mode("overwrite").parquet("/mnt/formula1dl/processed/qualifying")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/qualifying")

# COMMAND ----------

# df.show(5)
# Databricks notebook source
# display(dbutils.fs.mounts())

# COMMAND ----------

# %fs
# ls mnt/formula1dl/raw


dbutils.widgets.text("param_data_source", "")


# COMMAND ----------

v_env = dbutils.widgets.get("param_data_source")

# COMMAND ----------

v_env

# COMMAND ----------

# MAGIC %run "../includes/configuration"
# MAGIC

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------



# COMMAND ----------

circuits_df = spark.read \
.option("header", True) \
.option("inferSchema", True) \
.csv(f"{raw_folder_path}/circuits.csv")

# COMMAND ----------

# circuits_df.show()

# COMMAND ----------

# circuits_df.printSchema()

# COMMAND ----------

# circuits_df.describe().show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### select df

# COMMAND ----------


circuits_df = circuits_df.select('circuitId','circuitRef', 'name', 'location', 'country', 'lat', 'lng', 'alt')

### we can also access fileds like circuits_df.select(circuits_df.circuitId) or circuits_df.select(circuitId["circuitId"])
### we can also use col like    circuits_df.select(col("circuitId"))

### for that we need to import col from pyspark.sql.functions import col


#circuits_df.select('circuitId')
#circuits_df.select(circuits_df.circuitId)
#circuits_df.select(circuitId["circuitId"])
#circuits_df.select(col("circuitId"))

#we can use alias col("circuitId").alias("c_id") 


# COMMAND ----------

# circuits_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename columns

# COMMAND ----------

# circuits_renamed_df = circuits_df.withColumnRenamed("circuitId", "circuit_id")
# .withColumnRenamed("lat", "latitude")

# COMMAND ----------

# MAGIC %md
# MAGIC ### adding new column

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp, lit
 circuits_final_df = circuits_df.withColumn("ingestion_date", current_timestamp())

# COMMAND ----------

# circuits_final_df.show(5)



# COMMAND ----------

# circuits_final_df = circuits_df.withColumn("ingestion_date", current_timestamp())
circuits_final_df = add_ingestion_date(circuits_df)
# circuits_final_df = circuits_final_df.withColumn("env", lit("prod"))
circuits_final_df = circuits_final_df.withColumn("env", lit(v_env))

# COMMAND ----------

# circuits_final_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

circuits_final_df.write.mode("overwrite").parquet("/mnt/formula1dl/processed/circuits")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/circuits")

# COMMAND ----------

 df.show(5)

# COMMAND ----------


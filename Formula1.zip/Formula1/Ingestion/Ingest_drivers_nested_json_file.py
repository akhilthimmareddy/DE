# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

name_schema = StructType(fields=[StructField("forename", StringType(), True),
                         StructField("surname", StringType(), True)])

# COMMAND ----------

driver_schema = StructType(fields=
                        [StructField("driverId", IntegerType(), True),
                         StructField("driverRef", StringType(), True),
                         StructField("number", IntegerType(), True),
                         StructField("code", StringType(), True),
                         StructField("name", name_schema), 
                         StructField("dob", DateType(), True),
                         StructField("nationality", StringType(), True),
                         StructField("url", StringType(), True)]
                           )

# COMMAND ----------

drivers_df = spark.read \
.schema(driver_schema) \
.json("dbfs:/mnt/formula1dl/raw/drivers.json")

# COMMAND ----------

from pyspark.sql.functions import col,concat, current_timestamp, lit

# COMMAND ----------


drivers_updated_df = drivers_df.withColumn("ingestion_date", current_timestamp()) \
                    .withColumn("name", concat(col("name.forename"), lit(" "), col("name.surname"))) 
    


# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

drivers_updated_df.write.mode("overwrite").parquet("/mnt/formula1dl/processed/drivers")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/drivers")

# COMMAND ----------


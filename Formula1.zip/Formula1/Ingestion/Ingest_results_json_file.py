# Databricks notebook source
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

results_df = spark.read \
.option("header", True) \
.option("inferSchema", True) \
.json("dbfs:/mnt/formula1dl/raw/results.json")

# COMMAND ----------

from pyspark.sql.functions import col,concat, current_timestamp, lit

# COMMAND ----------

results_df = results_df.withColumn("Ingestion_date", current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC ### writing this df to file system in parquet format

# COMMAND ----------

results_df.write.mode("overwrite").partitionBy("raceId").parquet("/mnt/formula1dl/processed/results")

# COMMAND ----------

# MAGIC %md
# MAGIC ### reading data from parquet file to df
# MAGIC

# COMMAND ----------

df = spark.read.parquet("/mnt/formula1dl/processed/results")
# Databricks notebook source
# MAGIC %md
# MAGIC #### Acess Azure Data Lake using access keys using secret

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope = 'f1-scope')

# COMMAND ----------

f1_secret_key = dbutils.secrets.get(scope='f1-scope', key = 'f1-access-key')

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlthm.dfs.core.windows.net", 
               f1_secret_key)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlthm.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlthm.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------


# Databricks notebook source
# MAGIC %md
# MAGIC #### Acess Azure Data Lake using access keys

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1dlthm.dfs.core.windows.net", 
               "")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlthm.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlthm.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------


# Databricks notebook source
# MAGIC %md
# MAGIC #### Acess Azure Data Lake using SAS token

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlthm.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1dlthm.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1dlthm.dfs.core.windows.net", "sp=rl&st=2025-03-02T03:49:03Z&se=2025-03-02T11:49:03Z&spr=https&sv=2022-11-02&sr=c&sig=B9PlfUYGq1VDZLjQ9tfy6hYLEakWBTjL6WHc%2Bc6oOps%3D")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlthm.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlthm.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

